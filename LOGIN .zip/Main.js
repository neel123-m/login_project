$("#b1").click(function(){
  
 var h= $(".p1").val()
 var e= $(".p2").val()
 
 if(h!="" && e!="")
 {
   if(h==e)
   {
     alert("Successful")
     
     
   }
   else{
     alert("Password Denied")
     
     
     
     
   }
   
   
   
   
 }
 else{
   
   alert("Please Enter Password")
 }
  
  
  
  
})

$("#b2").click(function(){
  
  var h= $(".p1").val("")
 var e= $(".p2").val("")

  
  
  
  
})